﻿Chrit Hameleers 3978125
Maguell Sandifort 3898903
Sam de Redelijkheid 4025458

---------------------------------------------------------

BUILD INSTRUCTIONS:

The code is written in C#, using Visual Studio 2013 Ultimate Edition.
The project can be built by opening the solution file and selecting Build -> Build Solution.
Alternatively, Debug -> Start Debugging will also build the project.
The executable can then be found here: /RoomsOfDoom/bin/Debug/RoomsOfDoom.exe

An executable will also be delivered with this build. 
Do note that the "Enemies and packs" folder needs to be in the directory as the executable, or the program will not run.

---------------------------------------------------------

GAME CONTROLS:

AT THE START SCREEN

s: State seeding
l: Load players state from file
c: Continue playing
r: Select a replay to watch

IN BETWEEN DUNGEONS

s: Save player state to file
l: Load players state from file
c: Continue playing

IN A DUNGEON

w: Move upwards
a: Move left
s: Move downwards
d: Move right
e: Skip a turn
z: toggle debug mode
x: (debug mode only) let all packs perform a move
1: Use a potion
2: Use a time crystal
3: Use a magic scroll
4: Use the key to go to the next level (after you obtain it)
SHIFT + item key: (debug mode only) increase corresponding item by 1

DEBUG MODE:

Below the arena, the dungeon information is shown, for example:

N0(1,2,3,)[(D╦)(D)(♣ÅR)]
>N1(0,)[(&~)(1▒+Z)]
N2(0,3,)[(~╝#g)(0╝#Rd)]
!B3(2,0,4,6,)[(3█ÅR)(TDo)]
N4(3,5,)[]
N5(4,)[(HKV&╦)]
N6(3,)[]

Legend:
Nodetype nodenumber (adjacent node numbers)[(enemies in pack 1)(enemies in pack 2)]

N = node
B = bridge
> = Current node (where the player is)
! = locked bridge (unconquered)

3█ indicates that this pack has a defend order for node 3 (which is always a bridge)
1▒ indicates that this pack has a hunt order, with the last known player location being node 1

Below the dungeon information, information about the random state is given

Seed: 1679845113   The current seed that the random uses
Call count: 3185   The amount of random calls that were made since the start of the dungeon

To the right of the arena, information about the enemy is shown.
Its glyph, name and current hp is shown and when debug mode is active, their damage and speed is shown


Additional notes:

Move into enemies to deal damage to them.
Regular rooms are green, red rooms are bridges, yellow rooms are key rooms.
After a pack has been defeated, items can show up. They are as follows:
'1': Potion  '2': Time Crystal  '3': Magic Scroll
Yellow rooms hold a key '>' that will grant you access to the next level.
An enemy can take action for an amount of turns equal to its speed stat, before having to rest for a turn. This is the time to strike.