﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoomsOfDoom
{
    public enum Direction : byte
    {
        Up = 1,
        Down = 2,
        Left = 4,
        Right = 8
    }
}
