Chrit Hameleers 3978125
Maguell Sandifort 3898903
Sam de Redelijkheid 4025458

---------------------------------------------------------

BUILD INSTRUCTIONS:

The code is written in C#, using Visual Studio 2013 Ultimate Edition.
The project can be built by opening the solution file and selecting Build -> Build Solution.
Alternatively, Debug -> Start Debugging will also build the project.
The executable can then be found here: /RoomsOfDoom/bin/Debug/RoomsOfDoom.exe

An executable will also be delivered with this build. 
Do note that the "Enemies and packs" folder needs to be in the directory as the executable, or the program will not run.

---------------------------------------------------------

GAME CONTROLS:

AT THE START SCREEN / IN BETWEEN DUNGEONS

s: Save player state to file
l: Load players state from file
c: Continue playing

IN A DUNGEON

w: Move upwards
a: Move left
s: Move downwards
d: Move right
e: Skip a turn
1: Use a potion
2: Use a time crystal
3: Use a magic scroll
4: Use the key to go to the next level (after you obtain it)

Additional notes:

Move into enemies to deal damage to them.
Regular rooms are green, red rooms are bridges, yellow rooms are key rooms.
After a pack has been defeated, items can show up. They are as follows:
'1': Potion  '2': Time Crystal  '3': Magic Scroll
Yellow rooms hold a key '>' that will grant you access to the next level.
